
<!--
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8"> 
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <link href="./vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <script src="./vendor/jquery/jquery.min.js"></script>
  <script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    </head>
-->
<!--<p>This is header</p>-->

  <!-- Navigation -->

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">TedTech.in
          <img src="./images/logos/logo_nav.png">
        </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">

          </li>
          <li class="nav-item">
          
            <span class="sr-only">(current)</span>
          </li>
          <li class="nav-item">
          </li>
          <li class="nav-item">
          </li>
        </ul>
      </div>
    </div>
  </nav>
