// Bid status closed
// Project status closed
// email uploader that the project is finished
// Change uploader ongoing to NO
// 