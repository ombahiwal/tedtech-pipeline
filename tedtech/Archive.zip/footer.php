  <footer class="py-5 bg-dark">
    <div class="container">
        
      <p class="m-0 text-center text-white">Copyright &copy; TedTech.in - 2019</p>
<!--        <span id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=wBzXsJr3uYr5Fgv4R6u1K9bSZULf545sIcsryTgqbCpdkguase1DYKd5wEPi"></script></span>-->
    </div>
    <!-- /.container -->
  </footer>